# 21
"""
*******
*    *
*    *
*    *
*    *
*******
"""

for i in range(6):
    if i == 0 or i == 5:
        print('*' * 7)
    else:
        print('*' + ' ' * 4 + '*')