# 23
"""
12345
2345
345
45
5
45
345
2345
12345
"""

for i in list(range(5)) + list(range(3, -1, -1)):
    for j in range(i, 5):
        print(j+1, end='')
    print()