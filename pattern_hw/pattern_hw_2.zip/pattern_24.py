# 24
# Made In one go!
"""
1 2 3 4 5
 2 3 4 5
  3 4 5
   4 5
    5
   4 5
  3 4 5
 2 3 4 5
1 2 3 4 5
"""

for i in list(range(5)) + list(range(3, -1, -1)):
    print(' ' * i, end='')

    for j in range(i, 5):
        print(j+1, end=' ')
    print()