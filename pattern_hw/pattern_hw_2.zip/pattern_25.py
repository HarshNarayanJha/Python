# 25
"""
A
BC
DEF
GHIJ
KLMNO
"""

for i in range(15):
    print(chr(65+i), end='')

    if i in [0, 2, 5, 9]:
        print()